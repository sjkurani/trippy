<html>
	<head>
	<title> Quest</title>
	<script src="./jquery.js"></script>
	<script>
	$(document).ready(function(){
		$("#btn1").click(function(){	
		/*var wheight=$(window).height();alert(wheight+"WHI");
		var dheight=$(document).height();alert(dheight+"DHI");
		var dwidth=$(document).width();alert(dwidth+"DWI");
		var wwidth=$(window).width();alert(wwidth+"WwI");
		var sheight=screen.height();alert(wheight);
		var swidth=screen.width();alert(wheight);*/
			
			$("#pre1").toggle(1000);
			var btn1=document.getElementById("btn1");
			$("#secondexp").show(1000);
			btn1.value="hide";
			$("#secondexp").hide(1000);
			btn1.value="Click Here For Next";
			});
	$("#first").mouseenter(function(){
$("#dd").show(400);});
	$("#dd").mouseout(function(){
$("#dd").hide(1000);});
	});
	</script>
	<!--<link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>-->
	<link rel="shortcut icon" type="image/x-icon" href="./image/favicon.ico">
	<link rel="stylesheet" href="./style1.css"/>
	</head>
<body>
<form>
	<div id="side">
		<ul>
			<li  class="sideli" >
			<a title="Home" href="#">
			<img src="./images/favicon.ico"/>
			</a>
			</li>
			<li  class="sideli" >
			<a title="Advantages" href="#Advantages">
			<img src="./images/favicon.ico"/>
			</a>
			</li>
			<li class="sideli">
			<a title="Why Trippy Back" href="#whytrippyback" >
			<img src="./images/favicon.ico"/>
			</a>
			</li>
			<li class="sideli">
			<a title="Gallery" href="#gallery">
			<img src="./images/favicon.ico"/>
			</a>
			</li>
			<li class="sideli">
			<a title="suggest us" href="#suggest">
			<img src="./images/favicon.ico"/>
			</a>
			</li>
			<li class="sideli">
			<a title="Experience At Trippy Back" href="#experience">
			<font hidden>Experience</font><img src="./images/favicon.ico"/>
			</a>
			</li>
		</ul>
	</div>
	<div id="header" class="container" style="z-index:3">
	    <div id="logo">
	    <a href="#"><img src="./images/logo.png" style="width:200px;height:80px;"/></a>	
	    </div>
   		<div id="menu">
			<ul> 
			<li><a href="#">Home </a></li>
			<li><a href="#Advantages" >Advantages </a></li>
			<li><a href="#whytrippyback" >Why Trippyback</a></li>
			<li><a href="#gallery" >Gallery</a></li>
			<li><a href="#" >Suggest Us</a></li>
			<li><a href="#Experience" >Experience at trippy back</a></li>
			</ul>
			</div>
	        </div>
	<br>
	<img class="images" src="./images/22.jpg" style="float:right;height: 490px;margin-right: 0px;margin-bottom: 0px;margin-top: 0.5;"/>
	<h1 class="block" >WHAT IS QUEST ?</h1>
	<div id="whatisquest" class="whatisquest">
	Quest is a series of educative travel plans brought to you by the <b>TrippyBack</b> Family.The Quest series of tailor made tours are designed to give students and young professionals in depth practical knowledge of their streams of profession and education.Quest was started by the Trippyback think tank to bridge the gap between quality of "knowledge" seeked in a knowledge trip vis a vis the quality provided.
Quest aims to reach out to young professionals and students alike and enhance their knowledge about their chosen profession. Quest will open their minds to the past, present and the future of their stream.
Quest has been endorsed by various professionals in the industry, as it's the only tour program created by professionals for the professionals.
	</div>
<hr>
	<img src="./images/10.jpg"/>
	<div id="Advantages" style="float:right;width:625px;">
	<h1 class="block" >Advantages Of Quest?</h1>
	<section>
	<ol type="i">
	<li>Orientation by experts: Industry experts start our tours giving key takeaways that lie ahead for students.</li>
	<li>Relevant tie-ups in offshore locales: Most of the locations in our experiences have sessions with professionals in the trade, who will provide valuable insights and trade secrets.</li>
	<li>Comfortable and clean getting around: While our focus is on making the tour an epic experience, we strike a balance on clean and safe travel and ground transportation and similar accommodation.</li>
	<li>key takeaway pointers provided each day: We remind our travelers of their everyday learning's' in a fun and interactive way everyday to maximize learning recall..</li>

<li>Making the journey epic:  We firmly believe that the experience is more about the journey rather than the destination, hence focusing on making the journey as memorable as possible.</li>
	<li>Hands on practicality: Our experiences are designed to have maximum practicality which will compliment the transformation age of the student; as the average age of our traveler is about 22, slowly maturing them into the realms of his modern day profession. </li>
	<li>Diverse backgrounds; similar age group one passion: On a Quest experience, you are likely to find students and young professionals from varied backgrounds but driven by the same professional passion and also of the same age group. These minute details have been carefully planned to make that once in a lifetime educational tour a truly rewarding one. </li>
	</ol></section></div>	
<br><br><br><br>
<br><br><br><br>
<br><br><br><br>
<br><br>
	<div id="experience">
	<section id="firstexp">
	<h1 >Experiences At TrippyBack.</h1><br>hi i am shridhar it was my first trip with trippy back and it was awesome 
	<br>
<center><input type="button" id="btn1" value="Click Here For Next" style="background-color:gray;font-size:inherit;"/></center>
<p id="pre1"  hidden>
We enjoyed lot in the trip Thanks to Trippy Back.<br>
<input type="button" value="next"/>
</p></section>
<div id="footer">
<img src="./images/bottom.png" Value=""/>
</div>
<br>
<div>
<hr>
		<div class="container clearfix">			
			<br>
				<a id="whytrippyback" name="whytrippyback"><h1>Why TrippyBack</h1></a>
			</br>
			<div class="box sjk1">
				<h2>WE LISTEN</h2>
				<p>When it comes to planning your trip, we think the "you" part of “your trip" is important.That's why our International Program Team take the time to get to know you and learn what you want from your trip. They are then able to use their expertise to ensure you get the perfect tour for YOU!</p>
			</div>
			<div class="box sjk1">
				<h2>NO BAIT AND SWITCH</h2>
				<p>We don't understand overpromising and under-delivering. We want to partner with you and build a longstanding relationship, not just make a quick buck. And we're up front with everything. As a small group, if you need to be moved to a different trip, we'll offer you more options and communicate your options earlier. There's no signing up for Italy and ending up in England around here.</p>
			</div>
			<div class="box sjk1">
				<h2>OUR TOUR MANAGERS</h2>
				<p>"Exceptional. I cannot say enough how everyone adored Nil." "Raquel was excellent. In fact I can't imagine going back and traveling without her!" ACIS Tour Managers are carefully selected, rigorously trained, artfully matched with group leaders and wholly supported by our overseas network. It's no wonder they are so adored.</p>
			</div>
			<div class="box sjk1 ">
				<h2>HOTELS WHERE YOU WANT TO BE</h2>
				<p>Would you rather stay steps from Kensington Gardens or within earshot of Heathrow? We thought so-that's why we have the most centrally located hotels in the business. Commuting two hours a day is a waste of your precious overseas time. And comfort is essential, which is why all of our hotels are three- and four-star rated.</p>
			</div>
			<div class="box sjk1">
				<h2>AUTHENTIC AND SATISFYING MEALS</h2>
				<p>Food's an important part of the culture. With us you experience it. Paella in Spain, pasta in Italy-it's all food your students will eat and enjoy. Save the unappetizing mystery meats during early seatings at suburban hotels and emergency trips to fast food joints for the other guys.</p>
			</div>
			<div class="box sjk1">
				<h2>COMFORTABLE TRANSPORTATION</h2>
				<p>Let's face it, the time you spend getting from here to there isn't going to be your favorite part of the trip. We make the hassles of transportation easier with flights as direct as possible, 4-berth couchettes on overnight trains and buses that are clean, not packed to capacity and operated by reputable companies and drivers. These choices allow you to arrive in a new city feeling somewhat refreshed versus thinking of your transit as a penance for past sins..</p>
			</div>
			<div class="box sjk1 ">
				<h2>WE EXPECT THE UNEXPECTED</h2>
				<p>In travel things happen—illness, lost passports, even volcanic ash clouds. Our culture of care demands that we sweep in during an emergency (no matter how large or small) and save the day. Something falling short of your expectations? We're experts at fixing things fast. Hopefully you won't need to discover this for yourself, but isn't it reassuring to know we're here if you need us?</p>
			</div>
			<div class="box sjk1">				
				<h2>DESTINATION EXPERTISE</h2>
				<p>Our itineraries are crafted on 35 years of experience to maximize your time. From getting you into the Tower of London just as it opens and before the crowds arrive to an evening bike tour of Munich, your trip will run like clockwork because it's been designed by experts who wouldn't settle for anything less.</p>
			</div>
			<div class="box sjk1">				
				<h2>MORE INCLUSIONS</h2>
				<p>We include more. It’s not even close. Some are tour highlights like French cooking lessons or bullranch visits. Others are smaller touches like 24-hour vaporetto passes or timed entrances to the Accademia, which you might not think about until you’re reaching into your wallet or waiting in line for the umpteenth time on your trip. The reality is that low prices come from including less. We think you deserve more.
</p>
			</div>
			<div class="box sjk1">				
				<h2> EDUCATION IS EVERYWHERE</h2>
				<p>Education on an ACIS trip doesn’t happen on a schedule; it’s a constant—woven into the fabric of everything we do. Our tour managers don’t just know the information, they know how to deliver it so students are engaged. And the itineraries are designed to connect students with the people and culture they’re visiting, which is why hands-on Cultural Connections are included on every tour. </p>
			</div>
			<br><hr>
<center><a href="http://www.trippyback.com" target="_blank">TrippyBack</a>. All Rights Reserved.</center>
</div>
	<!--<div id="hello" style="position:relative;"><img src="./images/questtranspt.png" style="background-color:inherit;width:200px;height:200px;"/></div>-->
</form>
</body>
</html>
