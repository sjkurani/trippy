<html>
	<head>
		<style>
		.sidemenu 
		{
			background-color:#202020; 
			color:#00A3CC;
			font-size: 20px;
			max-width: 300px;
		}
		.sidemenu ul ul li 
		{
			position: absolute;
			left:150px;			
			max-width: 200px;
			font-size: 20px;
			display: none;
			margin:5px;
		}
		.sidemenu ul ul:hover li 
		{
			position:relative;
			display: block;
		}
		
		</style>
	</head>
		<div id="sidebar1" class="sidemenu">
			<ul>Quest For:
					<ul>
						Students/Traveller
						<li><a href="#">Parking guide</a></li>
						<li><a href="#">Select A Tour</a></li>
						<li><a href="#">About The Tour</a></li>
						<li><a href="#">On Board</a></li>
						<li><a href="#">Refer/Suggest</a></li>
					</ul>
					<ul>
						Teachers
						<li><a href="#">Select A Tour</a></li>
						<li><a href="#">About The Tour</a></li>
						<li><a href="#">Rewards</a></li>
						<li><a href="#">Refer/Suggest</a></li>
					</ul>
					<ul>
						Parents		
						<li><a href="#">Select A Tour</a></li>
						<li><a href="#">About The Tour</a></li>
						<li><a href="#">Safety</a></li>
						<li><a href="#">Refer/Suggest</a></li>
					</ul>
			</ul>
		</div>
		
		
		<div id="sidebar1" class="sidemenu">
			<ul>Why Asia:
					<ul>
						Importance of educative tour
					</ul>
					<ul>
						Which Tour is right for you
					</ul>
			</ul>
		</div>
	
</html>
